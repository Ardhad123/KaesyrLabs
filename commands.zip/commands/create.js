// commands/create.js
const { SlashCommandBuilder } = require('discord.js');
const { v4: uuidv4 } = require('uuid');
const ServerModel = require('../models/Server');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('create')
    .setDescription('Admin: create a Pterodactyl user & server for a Discord user')
    .addUserOption(opt => opt.setName('discorduser').setDescription('Discord user who will own the server').setRequired(true))
    .addStringOption(opt => opt.setName('name').setDescription('Server / username').setRequired(true))
    .addIntegerOption(opt => opt.setName('ram').setDescription('RAM in MB').setRequired(true))
    .addIntegerOption(opt => opt.setName('cpu').setDescription('CPU percent (e.g., 50)').setRequired(true))
    .addIntegerOption(opt => opt.setName('disk').setDescription('Disk in MB').setRequired(true)),

  async execute(interaction, deps) {
    const { ptero, encrypt, logger } = deps;
    const adminIds = (process.env.ADMIN_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
    if (!adminIds.includes(interaction.user.id)) {
      return interaction.reply({ content: 'You are not allowed to run this command.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const discordOwner = interaction.options.getUser('discorduser');
      const name = interaction.options.getString('name');
      const memory = interaction.options.getInteger('ram');
      const cpu = interaction.options.getInteger('cpu');
      const disk = interaction.options.getInteger('disk');

      // build email & password
      const email = `${name}-${Date.now()}@kaesyrlabs.internal`;
      const password = uuidv4().replace(/-/g, '').slice(0, 16);

      // create ptero user
      const userResp = await ptero.createUser({
        username: name,
        email,
        first_name: name,
        last_name: 'Kaesyr',
        password
      });

      // parse ptero user id (many panel versions)
      const pUserId = userResp?.data?.attributes?.id || userResp?.attributes?.id || userResp?.data?.id || userResp?.id;
      if (!pUserId) throw new Error('Unable to parse Pterodactyl user id from response');

      // find allocation
      const locationId = Number(process.env.PTERO_LOCATION_ID || 1);
      const preferNodeId = process.env.DEFAULT_NODE_ID || null;
      const preferAllocationId = process.env.DEFAULT_ALLOCATION_ID || null;

      const alloc = await ptero.findFreeAllocation(locationId, preferNodeId, preferAllocationId);
      if (!alloc || !alloc.allocationId) throw new Error('Failed to find free allocation');

      // create server
      const nest = Number(process.env.PTERO_NEST_ID || process.env.DEFAULT_NEST_ID || 1);
      const egg = Number(process.env.PTERO_EGG_ID || process.env.DEFAULT_EGG_ID || 1);
      const docker = process.env.PTERO_DOCKER_IMAGE;
      const startup = (process.env.PTERO_STARTUP_CMD || 'startup').replace('{{SERVER_MEMORY}}', String(memory));

      const srvResp = await ptero.createServer({
        name,
        user: pUserId,
        nest,
        egg,
        docker_image: docker,
        startup,
        memory,
        disk,
        cpu,
        allocation: alloc.allocationId
      });

      // parse server id/uuid
      const serverId = srvResp?.data?.attributes?.uuid || srvResp?.data?.id || srvResp?.id || srvResp?.attributes?.uuid || srvResp?.attributes?.id || null;

      // extract ip/port fallback
      const ipPort = ptero.extractIpPortFromServer(srvResp) || {};
      const ip = ipPort.ip || alloc.ip || null;
      const port = ipPort.port || alloc.port || null;

      const encryptedPassword = encrypt(password, process.env.CREDENTIALS_ENCRYPTION_KEY);

      const doc = new ServerModel({
        discordOwnerId: discordOwner.id,
        discordCreatorId: interaction.user.id,
        pteroUserId: String(pUserId),
        pteroEmail: email,
        encryptedPassword,
        serverId: String(serverId || ''),
        serverName: name,
        ip,
        port,
        nodeId: alloc.nodeId,
        nest,
        egg,
        memory,
        cpu,
        disk
      });

      await doc.save();

      return interaction.editReply({
        content: `✅ Created server **${name}** for ${discordOwner.tag}.\nServer ID: **${serverId || '(unknown)'}**\nIP: **${ip || 'pending'}** Port: **${port || 'pending'}**\nThey can run \`/panel\` to view details.`
      });
    } catch (err) {
      logger.error('create command error', err?.response?.data || err);
      return interaction.editReply({ content: `Error creating server: ${err.message || JSON.stringify(err)}` });
    }
  }
};