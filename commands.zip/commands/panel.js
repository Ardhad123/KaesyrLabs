// commands/panel.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ServerModel = require('../models/Server');

module.exports = {
  data: new SlashCommandBuilder().setName('panel').setDescription('Show your server IP/port and a button to view login info'),
  async execute(interaction, deps) {
    const { decrypt, logger } = deps;
    await interaction.deferReply({ ephemeral: true });
    try {
      const discordId = interaction.user.id;
      const server = await ServerModel.findOne({ discordOwnerId: discordId }).sort({ createdAt: -1 }).lean();
      if (!server) {
        return interaction.editReply({ content: 'No server found for your Discord account. Ask an admin to create one for you.' });
      }

      const embed = new EmbedBuilder()
        .setTitle(`Your Server: ${server.serverName}`)
        .addFields(
          { name: 'Panel URL', value: process.env.PTERO_URL || 'Not set', inline: true },
          { name: 'IP', value: server.ip || 'Pending', inline: true },
          { name: 'Port', value: server.port ? String(server.port) : 'Pending', inline: true },
          { name: 'Resources', value: `RAM: ${server.memory} MB • CPU: ${server.cpu}% • Disk: ${server.disk} MB` }
        )
        .setTimestamp();

      const btnId = `view_login_${server._id}`;
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(btnId).setLabel('View Login Info').setStyle(ButtonStyle.Primary)
      );

      return interaction.editReply({ embeds: [embed], components: [row], ephemeral: true });
    } catch (err) {
      logger.error('panel command error', err);
      return interaction.editReply({ content: 'Error retrieving your server info.' });
    }
  }
};