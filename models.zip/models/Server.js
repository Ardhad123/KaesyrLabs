// models/Server.js
const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
  discordOwnerId: { type: String, required: true, index: true },
  discordCreatorId: { type: String, required: true },
  pteroUserId: { type: String, required: true },
  pteroEmail: { type: String, required: true },
  encryptedPassword: { type: String, required: true },
  serverId: { type: String, required: true },
  serverName: { type: String, required: true },
  ip: { type: String },
  port: { type: String },
  nodeId: { type: String },
  nest: { type: Number },
  egg: { type: Number },
  memory: { type: Number },
  cpu: { type: Number },
  disk: { type: Number },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Server', Schema);