// utils/crypto.js
const crypto = require('crypto');

const algorithm = 'aes-256-gcm';

// key must be 32 bytes
function getKey(keyStr) {
  if (!keyStr) throw new Error('Encryption key not set');
  // if provided string shorter/longer, derive a 32 byte key using a hash to be safe
  const buf = Buffer.from(keyStr, 'utf8');
  if (buf.length === 32) return buf;
  // derive 32 bytes
  return crypto.createHash('sha256').update(buf).digest();
}

function encrypt(plaintext, keyStr = process.env.CREDENTIALS_ENCRYPTION_KEY) {
  const key = getKey(keyStr);
  const iv = crypto.randomBytes(12); // 12 bytes for GCM
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  // return hex-encoded iv:tag:encrypted
  return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

function decrypt(payload, keyStr = process.env.CREDENTIALS_ENCRYPTION_KEY) {
  const key = getKey(keyStr);
  const [ivHex, tagHex, encryptedHex] = payload.split(':');
  if (!ivHex || !tagHex || !encryptedHex) throw new Error('Invalid encrypted payload');
  const iv = Buffer.from(ivHex, 'hex');
  const tag = Buffer.from(tagHex, 'hex');
  const encrypted = Buffer.from(encryptedHex, 'hex');
  const decipher = crypto.createDecipheriv(algorithm, key, iv);
  decipher.setAuthTag(tag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}

module.exports = { encrypt, decrypt };